# Shell-file to allow for building package with no specified entry point
