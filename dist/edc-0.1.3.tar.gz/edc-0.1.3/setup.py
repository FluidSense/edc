# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['edc', 'edc.LinearEDC', 'edc.sedc-multiclass', 'edc.sedc_agnostic']

package_data = \
{'': ['*'],
 'edc': ['dist/*', 'img/*', 'tutorials/*', 'tutorials/.ipynb_checkpoints/*']}

install_requires = \
['ordered-set>=4.0.2,<5.0.0']

setup_kwargs = {
    'name': 'edc',
    'version': '0.1.3',
    'description': 'Search for Evidence Counterfactuals',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
